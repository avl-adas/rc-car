/* Inputs: current direction, requested direction, current speed (%), requested speed (%), Urgency (%)
   Outputs: Current monitoring
*/
byte motorDrive(boolean dirCur, boolean dirReq, byte speedCur, byte speedReq, byte urg) {
  byte pwmCur = round(map(speedCur, 0, 100, 0, 255)); //convert current speed to current pwm
  byte pwmReq = round(map(speedReq, 0, 100, 0, 255)); //convert requested speed to requested pwm
  byte delUrg = map(urg, 0, 100, 50, 0); //convert urgency to delay
  int pwmInc = ceil(abs(pwmReq - pwmCur) * urg / 100); //absolute value of pwm increment, high urgency is high increment
  if (pwmReq < pwmCur) {    //if the speed needs to be decreased
    pwmInc = -pwmInc;        //use negative increment
  }
  if (pwmCur == pwmReq) { //if speed is reached, reset loop counter
    cntr = 0; //loop counter
  }

  //.........................if the car goint in the correct direction.................................
  if (dirCur == dirReq) {
    /* smooth speed up and slowdown...
       These if statements will be checked first to determine if the speed change has just started or has neared the desired speed.
       They control the transition smoothness.
       If the conditions are not met, the speed will be changed in a linear fashion according to pwmInc.
       to adjust response time, first change the delay. To adjust response at beginning of speed change relative to end, adjust conditional statements for counter.
    */

    if (abs(pwmReq - pwmCur) < 3 || cntr < 2) {          //if the pwm is only off by one or two steps or counter is at zero or 1
      pwmCur = pwmReq + (pwmInc / abs(pwmInc)); //add or subtract 1 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }
    if ((abs(pwmReq - pwmCur) >= 3 && (abs(pwmReq - pwmCur) < 7)) || (cntr >= 2 && cntr < 4)) { //if the pwm is off by between 3 and 6 steps or counter is at 2 or 3
      pwmCur = pwmReq + 2 * (pwmInc / abs(pwmInc)); //add or subtract 2 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }
    if ((abs(pwmReq - pwmCur) >= 7 && (abs(pwmReq - pwmCur) < 15)) || (cntr >= 4 && cntr < 6)) { //if the pwm is off by between 7 and 11 steps or counter is at 4 or 5
      pwmCur = pwmReq + 4 * (pwmInc / abs(pwmInc)); //add or subtract 4 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }
    if ((abs(pwmReq - pwmCur) >= 15 && (abs(pwmReq - pwmCur) < 23)) || (cntr >= 6 && cntr < 7)) { //if the pwm is off by between 15 and 23 steps or counter is at 6 or 7
      pwmCur = pwmReq + 8 * (pwmInc / abs(pwmInc)); //add or subtract 8 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }


    // Linear speed change...

    pwmCur = pwmCur + pwmInc;     //add linear increment
    analogWrite(pwmPin, pwmCur);  //send current pwm signal
    cntr = cntr + 1; //add to counter
    delay(delUrg);     //give time to adjust speed

    if (pwmCur == pwmReq) {    //when the car reaches speed
      cntr = 0; //loop counter reset
    }
  }
  //........................................................................................................................
  //.........................if the car is switching directions.................................
  if (dirCur != dirReq) {
    pwmInc = -ceil(pwmCur * urg / 100); //pwm increment, high urgency is high increment

    /* smooth speed up and slowdown...
       These if statements will be checked first to determine if the speed change has just started or has neared the desired speed.
       They control the transition smoothness.
       If the conditions are not met, the speed will be changed in a linear fashion according to pwmInc.
       to adjust response time, first change the delay. To adjust response at beginning of speed change relative to end, adjust conditional statements for counter.
    */

    if (pwmCur < 3 || cntr < 2) {          //if the pwm is only off by one or two steps or counter is at zero or 1
      pwmCur = pwmReq + (pwmInc / abs(pwmInc)); //add or subtract 1 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }
    if ((pwmCur >= 3 && pwmCur < 7) || (cntr >= 2 && cntr < 4)) { //if the pwm is off by between 3 and 6 steps or counter is at 2 or 3
      pwmCur = pwmReq + 2 * (pwmInc / abs(pwmInc)); //add or subtract 2 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }
    if ((pwmCur >= 7 && pwmCur < 15) || (cntr >= 4 && cntr < 6)) { //if the pwm is off by between 7 and 11 steps or counter is at 4 or 5
      pwmCur = pwmReq + 4 * (pwmInc / abs(pwmInc)); //add or subtract 4 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }
    if ((pwmCur >= 15 && pwmCur < 23) || (cntr >= 6 && cntr < 7)) { //if the pwm is off by between 15 and 23 steps or counter is at 6 or 7
      pwmCur = pwmReq + 8 * (pwmInc / abs(pwmInc)); //add or subtract 8 to reach goal
      analogWrite(pwmPin, pwmCur);  //send current pwm signal
      cntr = cntr + 1; //add to counter
      delay(delUrg);     //give time to adjust speed
    }

    // Linear speed change...

    pwmCur = pwmCur + pwmInc;     //add linear increment
    analogWrite(pwmPin, pwmCur);  //send current pwm signal
    cntr = cntr + 1; //add to counter
    delay(delUrg);     //give time to adjust speed


    if (pwmCur == 0) {    //when the car is stopped
      dirCur = dirReq;    //now the car is considered to be going in the correct direction
      digitalWrite(dirPin, dirCur); //sends current direction to driver
      cntr = 0; //loop counter reset
    }
  }
  //........................................................................................................................
  speedCur = round(map(pwmCur, 0, 255, 0, 100)); //convert current pwm to current speed
}
